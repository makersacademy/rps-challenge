Introduction  
------------  

* Week three Makers Academy weekend challenge.

* Solo project.

* A Rock Paper Scissors game built using Sinatra.

* For one or two players.

* Two extra options!  Spock beats scissors and rock but loses to lizard and paper.  Lizard beats spock and paper but loses to scissors and rock.

* You can play it <a href="https://scissorslizardspock.herokuapp.com">here</a>.

<img width="1220" alt="screen shot 2017-06-08 at 07 50 06" src="https://user-images.githubusercontent.com/25392162/26915884-be7cd50e-4c1f-11e7-88bb-8491fe3bd014.png">
